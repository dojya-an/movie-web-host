window.__CONFIG__ = {
  // url must NOT end with a slash
  VITE_CORS_PROXY_URL: "https://hello-world-dry-shape-a8f2.gumgumdatabase28.workers.dev",
  VITE_TMDB_READ_API_KEY: "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0ZTY4YWJhYjdiNjc3NzhlMjMyOThhZGE5MDQ4YWRjYyIsInN1YiI6IjY1MWRmNzRmNzQ1MDdkMDExYzBmYmI5OCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.rfn6KVXzmPLYA7lnVdFqRAuXsy1cgdbXRZ1nrR9PG8I"
};